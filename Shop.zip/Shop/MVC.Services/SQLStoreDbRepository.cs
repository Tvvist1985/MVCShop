﻿namespace MVC.Services
{
    public class SQLStoreDbRepository : IStoreDbRepository
    {
        private readonly AppDbContext db;

        public SQLStoreDbRepository(AppDbContext db)
        {
            this.db = db;
        }
        
        // Получение 1 сущности из таблици
        public TEntity GetPage<TEntity>(int id) where TEntity : class
        {
            //Нахожу нужный экземпляр из таблици  только по id
            var page = db.Find<TEntity>(id);

            return page;
        }
        //Обощённый метод редактирования одного экземпляра
        public void Update<TEntity>(TEntity editEntity) where TEntity : class
        {           
            db.Update(editEntity);

            db.SaveChanges();         
        }
        //Получение таблици
        public IEnumerable<TEntity> GetAllEntities<TEntity>() where TEntity : class
        {
            //Получение Таблици           

            var tbl = db.Set<TEntity>();

            return tbl;
        }
        //Получение таблици для запросов
        public IQueryable<TSource> GetTableForRequest<TSource>() where TSource : class
        {
            IQueryable<TSource> tbl = db.Set<TSource>();

            return tbl;
        }
        //Добавляем Обьект
        public void Add<TSource>(TSource newEntity) where TSource : class
        {
            db.Add(newEntity);
            db.SaveChanges();
        }
        //Удаление
        public void Delete<TSource>(int id) where TSource : class
        {
            var pageToDelete = db.Find<TSource>(id);

            if (pageToDelete != null)
            {
                db.Remove(pageToDelete);
                db.SaveChanges();
            }

        }
        //Удаление по обьекту
        public void DeleteByEntity<TSource>(TSource entity) where TSource : class
        {
            if (entity != null)
            {
                db.Remove(entity);
                db.SaveChanges();
            }
        }

        public async Task AddAsync<TSource>(TSource newEntity) where TSource : class
        {
            await db.AddAsync(newEntity);
            await db.SaveChangesAsync();
        }

        public List<TResult> GetSeveralEntitiesFromDb<TEntity, TResult>(Func<IQueryable<TEntity>, List<TResult>> get) where TEntity : class
        {
            //Метод для выборки нескольких экземпляров  , а также членов экземпляров 
            IQueryable<TEntity> tbl = db.Set<TEntity>();
            return get(tbl);
        }

        public TEntity GetOneEntity<TEntity>(Func<IQueryable<TEntity>, TEntity> get) where TEntity : class
        {
            //Метод ля выборки одного экземпляра
            IQueryable<TEntity> tbl = db.Set<TEntity>();

            return get(tbl);
        }
        //Method: Для создания любого запроса в базу данных
        public TEntity DirectRequestToDatabase<TEntity>(Func<AppDbContext, TEntity> Get) => Get(db);
    }
}
