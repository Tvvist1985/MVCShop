﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MvcModels.Account;
using MvcModels.Data;
using MvcModels.Order;

namespace MVC.Services
{
    public class AppDbContext : DbContext
    {

        //Config/////////////////////////////////////////////////////////
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
            //Database.EnsureDeleted();
            Database.EnsureCreated();
        }
        //Category
        public DbSet<CategoryDTO> CategoryDTOs { get; set; } = null!;
        public void CategoryConfigure(EntityTypeBuilder<CategoryDTO> builder)
        {            
            //Переименование бызы
            builder.ToTable("tblCategories");
         
        }

        //Pages
        public DbSet<PagesDTO> PagesDTOs {get; set;} = null!;
        public void PagesConfigure(EntityTypeBuilder<PagesDTO> builder)
        {
            var Page1 = new PagesDTO { Id = 1, Title = "INDEX", Slug = "home", Bodu = "Index Body.   Login: Admin. Password: 11111.", Sorting = 0, HasSidebar = true }; //Add home page
            builder.HasData(Page1);

            //Переименование бызы
            builder.ToTable("tblPages");         
        }

        //Sidebar
        public DbSet<SidebarDTO> SidebarDTOs { get; set; } = null!;
        public void SidebarConfigure(EntityTypeBuilder<SidebarDTO> builder)
        {
            var Bar = new SidebarDTO { Id = 1, Bodu = "Index Bodu" };
            builder.HasData(Bar);
            //Переименование бызы
            builder.ToTable("tblSidebar");           
        }

        //tblProducts
        public DbSet<ProductDTO> Products { get; set; } = null!;
        public void ProductConfigure(EntityTypeBuilder<ProductDTO> builder)
        {           
            //Переименование бызы
            builder.ToTable("tblProducts");           
        }

        //tblUsers
        public DbSet<UserDTO> Users { get; set; } = null!;
        public void UserConfigure(EntityTypeBuilder<UserDTO> builder)
        {
            var admin = new UserDTO {
                Id = 1,
                FirstName = "Admin", 
                LastName="Admin",
                EmailAdress ="Admin@mail.ru",
                UserName="Admin",
                Password ="11111",
                ConfirmPassword = "11111" 
            };  //add admin

            builder.HasData(admin);
            //Переименование бызы
            builder.ToTable("tblUsers");            
        }

        //tblRoles
        public DbSet<RoleDTO> Roles { get; set; } = null!;
        public void RoleConfigure(EntityTypeBuilder<RoleDTO> builder)
        {
            var role1 = new RoleDTO { Id = 1, Name = "Admin" };
            var role2 = new RoleDTO { Id = 2, Name = "User" };
            builder.HasData(role1, role2);
            
            //Переименование бызы
            builder.ToTable("tblRoles");            
        }

        //tblUserRoles
        public DbSet<UserRoleDTO> UserRoles { get; set; } = null!;
        public void UserRoleConfigure(EntityTypeBuilder<UserRoleDTO> builder)
        {
            var role1 = new UserRoleDTO { id = 1, UserId = 1, RoleId = 1 };
            builder.HasData(role1);
            //Переименование бызы
            builder.ToTable("tblUserRoles");           
        }

        //tblOrders
        public DbSet<OrderDTO> Orders { get; set; } = null!;
        public void OrderConfigure(EntityTypeBuilder<OrderDTO> builder)
        {            
            //Переименование бызы
            builder.ToTable("tblOrders");                       
        }

        //tblOrderDetails
        public DbSet<OrderDetailsDTO> OrderDetails { get; set; } = null!;
        public void OrderDetailsConfigure(EntityTypeBuilder<OrderDetailsDTO> builder)
        {           
            //Переименование бызы
            builder.ToTable("tblOrderDetails");           
        }
       
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PagesDTO>(PagesConfigure);
            modelBuilder.Entity<SidebarDTO>(SidebarConfigure);
            modelBuilder.Entity<CategoryDTO>(CategoryConfigure);
            modelBuilder.Entity<ProductDTO>(ProductConfigure);
            modelBuilder.Entity<RoleDTO>(RoleConfigure);
            modelBuilder.Entity<UserDTO>(UserConfigure);
            modelBuilder.Entity<UserRoleDTO>(UserRoleConfigure);
            modelBuilder.Entity<OrderDTO>(OrderConfigure);
            modelBuilder.Entity<OrderDetailsDTO>(OrderDetailsConfigure);

        }
    }
}