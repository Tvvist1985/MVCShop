﻿using MvcModels.Data;

namespace MVC.Services
{
    public interface IStoreDbRepository
    {                  
        //Получение 1 сущности из таблици
        public TEntity GetPage<TEntity>(int id) where TEntity : class;

        //Обощённый метод редактирования одного экземпляра
        public void Update<TEntity>(TEntity editEntity) where TEntity : class;

        //Получение всех сущностей и DB .. Обощённый
        public IEnumerable<TEntity> GetAllEntities<TEntity>() where TEntity : class;

        //Получение таблици для запросов
        public IQueryable<TSource> GetTableForRequest<TSource>() where TSource : class;

        //Добавляем Обьект
        public void Add<TSource>(TSource newEntity) where TSource : class;
        //Создать обьект асинхронно
        public Task AddAsync<TSource>(TSource newEntity) where TSource : class;
        //Удаление
        public void Delete<TSource>(int id) where TSource : class;

        //Удаление по обьекту
        public void DeleteByEntity<TSource>(TSource entity) where TSource : class;
       
        public List<TResult> GetSeveralEntitiesFromDb<TEntity, TResult>(Func<IQueryable<TEntity>, List<TResult>> get) where TEntity : class;

        public TEntity GetOneEntity<TEntity>(Func<IQueryable<TEntity>, TEntity> get) where TEntity : class;
        //Method: Для создания любого запроса в базу данных
        public TEntity DirectRequestToDatabase<TEntity>(Func<AppDbContext, TEntity> Get) ;


    }
}
