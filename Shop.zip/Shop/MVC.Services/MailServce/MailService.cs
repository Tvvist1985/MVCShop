﻿using MimeKit;
using MailKit.Net.Smtp;

namespace MVC.Services.MailServce
{
    public class MailService
    {
        public async Task SendEmailAsync(string email, string subject, string message)
        {
            var emailMessage = new MimeMessage();

            emailMessage.From.Add(new MailboxAddress("Администрация сайта", "fl-13@mail.ru"));  //who is the from mess
            emailMessage.To.Add(new MailboxAddress("",email));
            emailMessage.Subject = subject;
            emailMessage.Body = new TextPart(MimeKit.Text.TextFormat.Html)
            {
                Text = message
            };

            using (var client = new SmtpClient())
            {   
                //Гугловский  порт  587
                await client.ConnectAsync("smtp.yandex.ru", 25, false);  //connect to server 
                await client.AuthenticateAsync("login@yandex.ru", "password");  //Athenticate to service  (need register to service)
                await client.SendAsync(emailMessage);

                await client.DisconnectAsync(true);
            }
        }
    }
}
