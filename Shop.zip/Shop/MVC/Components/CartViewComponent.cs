﻿using Microsoft.AspNetCore.Mvc;
using MvcModels.Cart;

namespace MVC.Components
{
    public class CartViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {

            //Меттод создания ссесии карзины
            //.......................................

            //Обьявляем модель CartVM

            CartVM model = new CartVM();
           
            //Получаем сессию 
            //var listCart = HttpContext.Session.Get<List<CartVM>>("cart");

            //Получаем сериальзованные данные из КУКИ
            var listCartCookie = HttpContext.GetCookie<List<CartVM>>("cart1");

            //Проверяем сессию корзины
            if (listCartCookie == null)
            {
                return View("_CartPartial", model);
            } 
            //Инача находм сериальзуем данные  и складываем цену     и количество
            else
            {               
                //Складываем цену товаров
                foreach (var item in listCartCookie)
                {
                    model.Quantity += item.Quantity;
                    model.Price += item.Quantity * item.Price;
                }
            }
     
            return View("_CartPartial", model);

        }

    }
}
