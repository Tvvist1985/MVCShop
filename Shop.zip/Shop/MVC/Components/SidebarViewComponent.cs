﻿using Microsoft.AspNetCore.Mvc;
using MVC.Services;
using MvcModels.Data;

namespace MVC.Components
{
    public class SidebarViewComponent : ViewComponent
    {
        private readonly IStoreDbRepository storeRepository;

        public SidebarViewComponent(IStoreDbRepository storeRepository)
        {
            this.storeRepository = storeRepository;
        }

        //Метод возвращает Панель Sidebar
        public IViewComponentResult Invoke()
        {                        
            SidebarDTO dto = storeRepository.GetPage<SidebarDTO>(1); //Находим панель
            return View("_SidebarPartial", dto);
        }
    }
}
