﻿using Microsoft.AspNetCore.Mvc;
using MVC.Services;
using MvcModels.Account;

namespace MVC.Components
{
    public class UserNavViewComponent : ViewComponent
    {
        private readonly IStoreDbRepository storeDbRepository;

        public UserNavViewComponent(IStoreDbRepository storeDbRepository)
        {
            this.storeDbRepository = storeDbRepository;
        }
        public IViewComponentResult Invoke()
        {
            //Компонент Авто Аунтефикации пользователя
            //...................................................

            //Проверям данные о пользователе  и получаем его имя
            string userName = HttpContext.User.Identity.Name;

          
            //Получаем пользователя из db
            var user = storeDbRepository.GetTableForRequest<UserDTO>().FirstOrDefault(x => x.UserName == userName);

            //Обьявляем модель и заполняем модель
            UserNavPartialVM model = new UserNavPartialVM()
            {
                FirstName = user.FirstName,
                LastName = user.LastName
            };

            return View("_UserNavPartial", model);
        }
    }
}
