﻿using Microsoft.AspNetCore.Mvc;
using MVC.Services;
using MvcModels.Data;

namespace MVC.Components
{
    public class CategoryViewComponent : ViewComponent
    {
        private readonly IStoreDbRepository storeDbRepository;

        public CategoryViewComponent(IStoreDbRepository storeDbRepository)
        {
            this.storeDbRepository = storeDbRepository;
        }

        public IViewComponentResult Invoke()
        {
            //Метод возвращает Список категорий

            //Находим панель
            List<CategoryDTO> categoryList = storeDbRepository.GetTableForRequest<CategoryDTO>().OrderBy(x => x.Sorting).ToList();

            return View("_CategoryPartial", categoryList);
        }
    }
}
