﻿using Microsoft.AspNetCore.Mvc;
using MVC.Services;
using MvcModels.Data;

namespace MVC.Components
{
    public class PageMenuViewComponent : ViewComponent
    {
        private readonly IStoreDbRepository storeDBRepository;

        public PageMenuViewComponent(IStoreDbRepository storeDBRepository)
        {
            this.storeDBRepository = storeDBRepository;
        }
        //Метод получение всех страниц  кроме home
        public IViewComponentResult Invoke()
        {                               
            List<PagesDTO> pages = storeDBRepository.GetAllEntities<PagesDTO>().OrderBy(x => x.Sorting).Where(x => x.Slug != "home").ToList();

            return View("_PagesMenuPartial", pages);
        }
    }
}
