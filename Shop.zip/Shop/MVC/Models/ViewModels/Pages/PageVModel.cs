﻿using MvcModels.Data;
using System.ComponentModel.DataAnnotations;

namespace MVC.Areas.Admin.Models.ViewModels.Pages
{
    public class PageVModel
    {

        public int Id { get; set; }
        [Required]
        [StringLength(50, MinimumLength = 3)]
        public string Title { get; set; } = null!;
        public string Slug { get; set; }
        [Required]
        [StringLength(int.MaxValue, MinimumLength = 3)]
        public string Bodu { get; set; } = null!;
        public int Sorting { get; set; }
        //Отображение имени
        [Display(Name = "Sidebar")]
        public bool HasSidebar { get; set; }
        //этот  для того если вдруг ничегое не прелетит в следующий конструктор
        public PageVModel()
        {

        }

        //Присваиваем значение модели из DB в  эту модель  для безопасности  ХЗ чё за патерн  
        public PageVModel(PagesDTO row)
        {
            Id = row.Id;    
            Title = row.Title;  
            Slug = row.Slug;    
            Bodu = row.Bodu;
            Sorting = row.Sorting;  
            HasSidebar = row.HasSidebar;    
        }
       
      
    }
}
