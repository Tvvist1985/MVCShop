﻿using System.Text.Json;

namespace MVC
{
    public static class CookieExtensions 
    {
        //Методы расширения   для создания и получения куки
        public static void SetCookie<T>(this HttpContext cookie, string key, T value)
        {           
            string? jsonText;

            string path = "cart.json";

            //Сериализация данных (перевод обьекта в строку через стрим)
            //Этот метод через стрим для ознакомления  а вообще обыную сериализацию
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
            {
                JsonSerializer.Serialize(fs, value);
            }
            //Перевод данных из JSON в строку
            using (StreamReader reader = new StreamReader(path))
            {
                //также можно получить через бинарный формат 
                jsonText =  reader.ReadToEnd();
            }

            //Удаление JSON
            File.Delete(path);

            //Установка время куки
            CookieOptions cookieOptions = new CookieOptions();
            cookieOptions.Expires = DateTime.Now.AddDays(2);

            //Передача куки в ответе
            cookie.Response.Cookies.Append(key, jsonText, cookieOptions);

        }

        public static T? GetCookie<T>(this HttpContext cookie, string key)
        {
            //Метод расширения для (дессериализации куки в обьект)
            //......................................................

            //Получаем данные из cookie
            var value = cookie.Request.Cookies[key];
                   
            //Дессиарилизуем  и оправляем ответ         
            return value == null ? default(T) : JsonSerializer.Deserialize<T>(value);
        }
    }


    

}
