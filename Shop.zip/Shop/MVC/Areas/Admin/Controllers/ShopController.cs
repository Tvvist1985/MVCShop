﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVC.Services;
using MvcIndexViewModel;
using MvcModels.Data;
using System.Drawing;
using Microsoft.EntityFrameworkCore;
using MvcModels.Order;
using MvcModels.Admin;
using MvcModels.Account;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using System.Text.Json;

namespace MVC.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class ShopController : Controller
    {
        private readonly IStoreDbRepository storeDbRepository;
        private readonly IWebHostEnvironment webHostEnvironment;

        public ShopController(IStoreDbRepository storeDbRepository, IWebHostEnvironment webHostEnvironment)
        {
            this.storeDbRepository = storeDbRepository;
            this.webHostEnvironment = webHostEnvironment;
        }
        [HttpGet]
        //Получает все названия        
        public ActionResult Categories()
        {
            //List
            IEnumerable<CategoryDTO> categoriesDbSet ;
            //Достаём и сортеруем таблицу по сортингу таблицу из базы

            categoriesDbSet = storeDbRepository.GetTableForRequest<CategoryDTO>().OrderBy(x => x.Sorting).ToList();

            return View(categoriesDbSet);
        }

        // post: ShopController     
        [HttpPost]
        public string AddNewCategory(string catName)
        {
            //Обьявляем строковую переменнуй ID
            string id;

            //проверяем на уникальность
            if (storeDbRepository.GetTableForRequest<CategoryDTO>().Any(x => x.Name == catName))
                //Это возращаеться обрезанная строка из скрипта Categories....
                return "titletaken";
            //Инициализируем  модель DTO
            //После сохранения в базе Update  даже из вне   это экземпляр получит ID
            CategoryDTO dto = new CategoryDTO();
            //Добавляем данны в модель
            dto.Name = catName;
            dto.Slug = catName.Replace(" ", "-").ToLower();
            dto.Sorting = 100;

            //Сохраняем модель
            storeDbRepository.Add(dto);

            //Получаем ID чтобы его вурнуть
            id = dto.Id.ToString();

            return id;
        }
       
        [HttpPost]
        public void ReorderCategories(int[] id)
        {            
            //Начальный счётчик
            //home по умолчанию 0
            int count = 1;
            //Сортировка для каждой таблици
            foreach (var pageId in id)
            {
                //получаем обьект
                var model = storeDbRepository.GetPage<CategoryDTO>(pageId);
                model.Sorting = count;
                //СОхраняем обьект
                storeDbRepository.Update(model);

                count++;
            }

        }
        //Admin/Shop/ReorderCategories
        [HttpGet]
        public IActionResult DeleteCategory(int id)
        {
            var category = storeDbRepository.DirectRequestToDatabase(p => p.CategoryDTOs.Include(p => p.Products).FirstOrDefault(p => p.Id == id));
            storeDbRepository.DeleteByEntity(category); //Delete category

            foreach (var produt in category.Products)//Delete directories
                Task.Run(() => DeleteDirectory(produt.Id));

            TempData["SM"] = "You delete a page!";

            return RedirectToAction("Categories");
        }       
        //Переименование категорий
        [HttpPost]
        public string RenameCategory(string newCatName, int id)
        {
            //Проверяем имя на уникальность
            if (storeDbRepository.GetTableForRequest<CategoryDTO>().Any(x => x.Name == newCatName))
            {
                //Это возращаеться обрезанная строка из скрипта Categories....
                return "titletaken";
            }

            //Получаем модель из базы
            var model = storeDbRepository.GetPage<CategoryDTO>(id);
            //Редактируем
            model.Name = newCatName;
            model.Slug = newCatName.Replace(" ", "-").ToLower();
            //СОхраняем
            storeDbRepository.Update(model);

            //Вернём слово  КОТОРОЕ ниначто не влияет  хз почему не void
            return "ok";
        }

        //Method: Get all product 
        [HttpGet]
        public IActionResult AddProduct()
        {
            //Обьявляем модель Product
            ProductDTO model = new ProductDTO();
            //Добавть в модель наши категории для переноса на страницу 
            model.Categories = new SelectList(storeDbRepository.GetAllEntities<CategoryDTO>().ToList(), "Id", "Name");

            return View(model);
        }
      
        [HttpPost]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Interoperability", "CA1416:Проверка совместимости платформы", Justification = "<Ожидание>")]
        //[SupportedOSPlatform("linux")]
        //[SupportedOSPlatform("ios14.0")]
        public IActionResult AddProduct(ProductDTO model, IFormFile? file)
        {           
            //Проверка на валидность   то заходим внутьрь и меняе
            if (!ModelState.IsValid)
            {
                model.Categories = new SelectList(storeDbRepository.GetAllEntities<CategoryDTO>().ToList(), "Id", "Name");

                return View(model);
            }

            //Проверяем имя товара на уникальность
            if (storeDbRepository.GetTableForRequest<ProductDTO>().Any(x => x.Name == model.Name))
            {
                model.Categories = new SelectList(storeDbRepository.GetAllEntities<CategoryDTO>().ToList(), "Id", "Name");

                //Вывод ошибки
                ModelState.AddModelError("", "That product name is taken!");
                return View(model);
            }

            //Переменна для Product Id
            int id;

            //Создаём ProductDTO         
            CategoryDTO catDTO = storeDbRepository.GetTableForRequest<CategoryDTO>().FirstOrDefault(x => x.Id == model.CategoryId);
            //Присваиваем имя категории
            model.CategoryName = catDTO.Name;
            //Slug модели переводим в нижний регистр
            model.Slug = model.Name.Replace(" ", "-").ToLower();
            //Сохраняем модель чтобы получить Id
            storeDbRepository.Add(model);

            //Получаем id модели
            id = model.Id;

            //Сообщение о удаче
            TempData["SM"] = "You have added a product!";

            //Регион для удобства
            //Тут добавляем и сохраняем изображения
            #region Upload Image
            // создаём путь к папке, где будут храниться файлы
            var originalDirectory = Path.Combine(webHostEnvironment.WebRootPath, "Imagess\\Uploads");
            //пути

            var pathString1 = Path.Combine(originalDirectory, "Products");
            var pathString2 = Path.Combine(originalDirectory, "Products\\" + id.ToString());
            var pathString3 = Path.Combine(originalDirectory, "Products\\" + id.ToString() + "\\Thumbs");
            var pathString4 = Path.Combine(originalDirectory, "Products\\" + id.ToString() + "\\Gallery");
            var pathString5 = Path.Combine(originalDirectory, "Products\\" + id.ToString() + "\\Gallery\\Thumbs");

            //Проверка и создания папок   где будут храниться файлы
            if (!Directory.Exists(pathString1))
                Directory.CreateDirectory(pathString1);

            if (!Directory.Exists(pathString2))
                Directory.CreateDirectory(pathString2);

            if (!Directory.Exists(pathString3))
                Directory.CreateDirectory(pathString3);

            if (!Directory.Exists(pathString4))
                Directory.CreateDirectory(pathString4);

            if (!Directory.Exists(pathString5))
                Directory.CreateDirectory(pathString5);

            //Проверяем был ли фаил загружен
            if (file != null && file.Length > 0)
            {
                //получаем расширение файла
                string ext = file.ContentType.ToLower();

                //Проверяем расширение файла
                if(ext != "image/jpg" &&
                   ext != "image/jpeg" &&
                   ext != "image/pjpeg" &&
                   ext != "image/gif" &&
                   ext != "image/x-png" &&
                   ext != "image/png" )
                {
                    model.Categories = new SelectList(storeDbRepository.GetAllEntities<CategoryDTO>().ToList(), "Id", "Name");
                    //Вывод ошибки
                    ModelState.AddModelError("", "The image was not uploaded - wrong image extension!");

                    return View(model);
                }

                //Объявляем переменную с именем изображения
                string imageName = file.FileName;

                //Сохраняем имя изображения модели в модель
                model.ImageName = imageName;
                storeDbRepository.Update(model);

                //Назначить пути к орегинальному и уменшенному изображению
                var path = Path.Combine(pathString2, imageName);
                var path2 = Path.Combine(pathString3, imageName);

                //Сохраняем орегинальное изображений           
                using (var fs = new FileStream(path, FileMode.Create))
                {
                    //копируем полученное фото на сервер 
                    file.CopyToAsync(fs);
                }
                

                //Создаём и Сохраняем уменьшенную копию изображений
                var image = Image.FromStream(file.OpenReadStream(), true, true);
                var newImage = new Bitmap(200, 200);

                using (Graphics a = Graphics.FromImage(newImage))
                {
                    a.DrawImage(image, 0, 0, 200, 200);
                    newImage.Save(path2);
                }              
            }
            #endregion

            return RedirectToAction("AddProduct");
        }
      
        [HttpGet]
        //Name это для поисковика
        public async Task<IActionResult> Products(string? name, int category = 0, int page = 1, SortState sortOrder = SortState.NameAsc)
        {
            //Метод списка товаров
            //GET: Admin/Shop/Products

            //Список категорий
            List<CategoryDTO> categories = storeDbRepository.GetAllEntities<CategoryDTO>().ToList();

            //определяем переменную для количества товаров на странице
            int pageSize = 3;

            //Создаём лист фильтраций
            IEnumerable<ProductDTO> produts; /*= new List<ProductDTO>(); */
            //Фильтрацияяяя .. проверка на поисковике недоделанная . но это не сложно
            if (category != 0)
            {
                produts = storeDbRepository.GetTableForRequest<ProductDTO>().Where(p => p.CategoryId == category).Include(x => x.Category).ToList(); 
            }
            else
            {
                produts = storeDbRepository.GetTableForRequest<ProductDTO>().Include(x => x.Category).ToList();
            }
            if (!string.IsNullOrEmpty(name))
            {
                produts = storeDbRepository.GetTableForRequest<ProductDTO>().Where(p => p.Name!.Contains(name)).Include(x => x.Category).ToList();
            }
           
            //сортировка
            switch (sortOrder)
            {
                case SortState.NameDesc:
                    produts = produts.OrderByDescending(s => s.Name);
                    break;
                case SortState.CategoryAsc:
                    produts = produts.OrderBy(s => s.Category!.Name);
                    break;
                case SortState.CategoryDesc:
                    produts = produts.OrderByDescending(s => s.Category!.Name);
                    break;
                default:
                    produts = produts.OrderBy(s => s.Name);
                    break;
            }

            //Передаём название категории  для вывод по умолчанию
            TempData["SelectCat"] = category == 0 ? "Все" : categories.FirstOrDefault(x => x.Id == category).Name;

            // пагинация
            var count = produts.Count();
            var items = produts.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            // формируем модель представления  + пастраничную навигацию
            IndexViewModel viewModel = new IndexViewModel(
                items,
                new PageViewModel(count, page, pageSize),
                new FilterViewModel(categories, category, name),
                new SortViewModel(sortOrder)
            );

            return View(viewModel);
        }
        //Метод редактиование товаров        
        [HttpGet]
        public IActionResult EditProduct(int id)
        {
            //получаем модель 
            var model =  storeDbRepository.GetPage<ProductDTO>(id);

            //проверяем
            if (model == null)
                return Content("That product does not exist.");

            //Создаём список категорий
            model.Categories = new SelectList(storeDbRepository.GetAllEntities<CategoryDTO>().ToList(), "Id", "Name");

            //Получаем все изображения из галереии

            model.GalleryImages = Directory.EnumerateFiles(Path.Combine(webHostEnvironment.WebRootPath, "Imagess\\Uploads\\Products\\" + id + "\\Gallery")).Select(fn => Path.GetFileName(fn));

            return View(model);
        }

        //Метод редактиование товаров  
        [HttpPost]
        public IActionResult EditProduct(ProductDTO model, IFormFile? file)
        {
            //получаем id товара
            int id = model.Id;

            //заполняем список  категорий  категориями 
            model.Categories = new SelectList(storeDbRepository.GetAllEntities<CategoryDTO>().ToList(), "Id", "Name");

            //Заполняем список фото
            model.GalleryImages = Directory.EnumerateFiles(Path.Combine(webHostEnvironment.WebRootPath, "Imagess\\Uploads\\Products\\" + id + "\\Gallery")).Select(fn => Path.GetFileName(fn));

            //проверяем  На валидность
            if(!ModelState.IsValid)
            {
                return View(model);
            }
            //проверка имя продукта на уникальность
            //идёт проверка  всех товаров кроме нашего текущего
            if (storeDbRepository.GetTableForRequest<ProductDTO>().Where(x => x.Id != id).Any(x => x.Name == model.Name))
            {
                //Вывод ошибки
                ModelState.AddModelError("", "That product name is taken!");

                return View(model);
            }

            //Переприсваиваем
            model.Slug = model.Name.Replace(" ", "-").ToLower();
            // Присваиваем имя категории через Id категории
            model.CategoryName = storeDbRepository.GetTableForRequest<CategoryDTO>().FirstOrDefault(x => x.Id == model.CategoryId).Name;
            //Апдейт
            storeDbRepository.Update(model);

            //Сообщение о удаче
            TempData["SM"] = "You have edited a product!";

            //Логика обработки изображений

            #region Image Update
            //Проверка загрузки файла  двойная  обязательно
            if(file != null && file.Length > 0)
            {
                //Получаем расширение файла
                string ext = file.ContentType.ToLower();

                //Прроверяем расширение файла
                if (ext != "image/jpg" &&
                  ext != "image/jpeg" &&
                  ext != "image/pjpeg" &&
                  ext != "image/gif" &&
                  ext != "image/x-png" &&
                  ext != "image/png")
                {
                    //Вывод ошибки
                    ModelState.AddModelError("", "The image was not uploaded - wrong image extension!");

                    return View(model);
                }

                //Указываем пути загрузки
                // создаём путь к папке, где будут храниться файлы
                var originalDirectory = Path.Combine(webHostEnvironment.WebRootPath, "Imagess\\Uploads");
                //пути
                var pathString1 = Path.Combine(originalDirectory, "Products\\" + id.ToString());
                var pathString2 = Path.Combine(originalDirectory, "Products\\" + id.ToString() + "\\Thumbs");

                //Создаём обьекты для управлениемя каталогов
                DirectoryInfo dir1 = new DirectoryInfo(pathString1);
                DirectoryInfo dir2 = new DirectoryInfo(pathString2);

                //Удаляем изображения
                foreach(var file2 in dir1.GetFiles())
                {
                    file2.Delete(); 
                }
                foreach (var file3 in dir2.GetFiles())
                {
                    file3.Delete();
                }
                //Объявляем переменную с именем изображения
                string imageName = file.FileName;

                //Сохраняем имя изображения модели в модель
                model.ImageName = imageName;
                storeDbRepository.Update(model);

                //Назначить пути к орегинальному и уменшенному изображению
                var path = Path.Combine(pathString1, imageName);
                var path2 = Path.Combine(pathString2, imageName);

                //Сохраняем орегинальное изображений           
                using (var fs = new FileStream(path, FileMode.Create))
                {
                    //копируем полученное фото на сервер 
                    file.CopyToAsync(fs);
                }

                //Создаём и Сохраняем уменьшенную копию изображений
                var image = Image.FromStream(file.OpenReadStream(), true, true);
                var newImage = new Bitmap(200, 200);

                using (Graphics a = Graphics.FromImage(newImage))
                {
                    a.DrawImage(image, 0, 0, 200, 200);
                    newImage.Save(path2);
                }
            }
            #endregion

            return RedirectToAction("EditProduct");
        }
        //Метод удаление товаров
        //Post: Admin/Shop/DeleteProduct/id
        [HttpGet]
        public IActionResult DeleteProduct(int id) 
        {
            //Удаляем из базы
            storeDbRepository.Delete<ProductDTO>(id);
            Task.Run(() => DeleteDirectory(id)); // Delete directory

            return RedirectToAction("Products");
        }

        [HttpPost]
        public void SaveGalleryImages(int id)
        {
            //Метод добавления изображения  в галерею
            //Post: Admin/Shop/
            //...........................................

            //Перебераем все полученные файлы
            foreach(var file in Request.Form.Files)
            {
                if(file != null && file.Length > 0)
                {
                    // создаём путь к папке, где будут храниться файлы
                    var originalDirectory = Path.Combine(webHostEnvironment.WebRootPath, "Imagess\\Uploads");
                    //пути
                  
                    var pathString1 = Path.Combine(originalDirectory, "Products\\" + id.ToString() + "\\Gallery");
                    var pathString2 = Path.Combine(originalDirectory, "Products\\" + id.ToString() + "\\Gallery\\Thumbs");

                    //Объявляем переменную с именем изображения
                    string imageName = file.FileName;

                    //Назначить пути к орегинальному и уменшенному изображению
                    var path = Path.Combine(pathString1, imageName);
                    var path2 = Path.Combine(pathString2, imageName);

                    //Сохраняем орегинальное изображений           
                    using (var fs = new FileStream(path, FileMode.Create))
                    {
                        //копируем полученное фото на сервер 
                        file.CopyToAsync(fs);
                    }

                    //Создаём и Сохраняем уменьшенную копию изображений
                    var image = Image.FromStream(file.OpenReadStream(), true, true);
                    var newImage = new Bitmap(200, 200);

                    using (Graphics a = Graphics.FromImage(newImage))
                    {
                        a.DrawImage(image, 0, 0, 200, 200);
                        newImage.Save(path2);
                    }
                }
                
            }
            
        }
       
        //Метод удаление ФОТО
        public void DeleteImage(int id, string imageName)
        {
           
            //Get: Admin/Shop/DeleteImage/id
            // создаём путь к папке, где будут храниться файлы
            var originalDirectory = Path.Combine(webHostEnvironment.WebRootPath, "Imagess\\Uploads");
            //пути
            var pathString1 = Path.Combine(originalDirectory, "Products\\" + id.ToString() + "\\Gallery\\" + imageName);
            var pathString2 = Path.Combine(originalDirectory, "Products\\" + id.ToString() + "\\Gallery\\Thumbs\\" + imageName);

            //Проверка  и удаление
            if (System.IO.File.Exists(pathString1))
                System.IO.File.Delete(pathString1);

            if (System.IO.File.Exists(pathString2))
                System.IO.File.Delete(pathString2);
        }

        [HttpGet]
        //Method: Show all orders of the current user
        public IActionResult GetOrder()
        {           
            var listOrders = storeDbRepository.DirectRequestToDatabase(p => p.Orders  //Get all orders current user            
            .Select(p => new
            {
                p.CreatedAt,
                p.OrderDetails.FirstName,
                p.OrderDetails.LastName,
                p.OrderDetails.EmailAdress,
                p.OrderDetails.ProductName,
                p.OrderDetails.OrderId,
                p.OrderDetails.Price,
                p.OrderDetails.Quantity
            }).ToList());

            var json = JsonSerializer.Serialize(listOrders); // Serialized to json           
            List<OrdersForAdminVM> ordersForUser = JsonSerializer.Deserialize<List<OrdersForAdminVM>>(json); //Dererialize to OrderVM

            return View(ordersForUser);
        }

        //Method: Delete full directory
        private void DeleteDirectory(int id)
        {         
            //Удаляем каталоги
            var originalDirectory = Path.Combine(webHostEnvironment.WebRootPath, "Imagess\\Uploads");
            var pathString = Path.Combine(originalDirectory, "Products\\" + id.ToString());
            if (Directory.Exists(pathString))
                Directory.Delete(pathString, true);
        }
    }
}
