﻿using Microsoft.AspNetCore.Mvc;
using MVC.Areas.Admin.Models.ViewModels.Pages;
using MvcModels.Data;
using MVC.Services;
using System.Data;
using Microsoft.AspNetCore.Authorization;

namespace MVC.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class PagesController : Controller
    {
        private readonly IStoreDbRepository storeRepository;
        private readonly AppDbContext db;
        // обьявляем список для  представления(PageVModel) (метод индекс)
        IEnumerable<PageVModel> pageList;
        private PagesDTO pagesDTO { get; set; } = new();
        //private SidebarDTO SidebarDTO { get; set; } = new();


        public PagesController(IStoreDbRepository storeRepository, AppDbContext db)
        {
            this.storeRepository = storeRepository;
            this.db = db;
        }
        //Admin/Pages
        // Получем все страници
        public IActionResult Index()
        {           
            //Инициализировать список из базы данных                         Выбираем все обьекты нашего   Х

            pageList = storeRepository.GetTableForRequest<PagesDTO>().OrderBy(x => x.Sorting).Select(x => new PageVModel(x)).ToList();

            //возвращаем список  в представления
            return View(pageList);
        }
   
        //Переход на страницу для Создания страниц
        [HttpGet]
        public IActionResult AddPage() => View();
  
        //Создаём страницу
        [HttpPost]
        public IActionResult AddPage(PageVModel model)
        {
            //Проверка модели на валидность  Если не валидно возвращаеться на исправление
            if(!ModelState.IsValid)            
                return View(model);            

            //Обьява переменной для краткого описания(slug)
            string slug;
            
            //Присвоение заголовка модели
            pagesDTO.Title = model.Title.ToUpper();   
            //Проверяем есть ли краткое описание  если нет присваиваем его
            if(string.IsNullOrWhiteSpace(model.Slug))            
                slug = model.Title.Replace(" ", "-").ToLower();            
            else            
                slug = model.Slug.Replace(" ", "-").ToLower();
            
            //Проверяем Заголовок и краткое описание  На уникальноe
            //Пробегает по всей базе и ищит похожие заголовки
            //Если нашол то отправляем на доработку
            if(db.PagesDTOs.Any(x => x.Title == model.Title))
            {
                //Добавляем ошибку
                ModelState.AddModelError("", "That title already exisit.");

                return View(model);
            }
            else if(db.PagesDTOs.Any(x => x.Slug == model.Slug))
            {
                //Добавляем ошибку
                ModelState.AddModelError("", "That slug already exisit.");

                return View(model);
            }
            //Присваиваем  оставшиеся значение нашей модели 
            pagesDTO.Slug = slug;
            pagesDTO.Bodu = model.Bodu;
            pagesDTO.HasSidebar = model.HasSidebar;
            //присваиваем 100 это при создании новой модели бросает сразу в конец списка
            //МОжно сделать проверку для home чтобы sorting был ..0.. а лучше базу переинициализировать
            pagesDTO.Sorting = 100;

            //Сохраняем модель в DB
            storeRepository.Add(pagesDTO);

            //Передаём сообщение через TemData
            TempData["SM"] = "You have added a new page!";

            //Переадрисация на метод Index

            return RedirectToAction("Index");
        }
        //Admin/Pages/EditPages/id
        //ПОлучение страници для Редактирования
        [HttpGet]
        public IActionResult EditPage(int id)
        {
            //Обьявим модель PageVModel
            PageVModel model;
            // полчаем страницу  по ID
            pagesDTO = storeRepository.GetPage<PagesDTO>(id);
            // доступна ли страница
            if(pagesDTO == null)            
                return Content("The page does not exist");
            
            //Инициализируем страницу данными
            model = new PageVModel(pagesDTO);

            return View(model);
        }
        //Admin/Pages/EditPages
        //Редактирование полученной страници
        [HttpPost]
        public IActionResult EditPage(PageVModel model)
        {
            //Проверяем на валидность 
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            // перевменная для краткого заголовка  Если не присвоить home  то проскочим проверку и она будет пустая
            string slug = "home";
            //Получаем страницу по id
            pagesDTO = storeRepository.GetPage<PagesDTO>(model.Id);
            //Присваиваем название из полученной модели в модель данных
            pagesDTO.Title = model.Title;
            //Проверка slug  если его нет то присвоить
            if(model.Slug != "home")
            {
                if(string.IsNullOrWhiteSpace(model.Slug))
                {
                    slug = model.Title.Replace(" ", "-").ToLower();
                }
                else
                {
                    slug = model.Slug.Replace(" ", "-").ToLower(); 
                }
            }

            //Проверяем slug и title  на уникальность
            if(db.PagesDTOs.Where(x => x.Id != model.Id).Any(x => x.Title == model.Title))
            {
                //добавляем ошибку
                ModelState.AddModelError("", "That title alredy exist.");
                return View(model);
            }
            else if (db.PagesDTOs.Where(x => x.Id != model.Id).Any(x => x.Slug == slug))
            {
                //добавляем ошибку
                ModelState.AddModelError("", "That slug alredy exist.");
                return View(model);
            }
            //Присваивавем остальное в модель
            pagesDTO.Slug = slug;
            pagesDTO.Bodu = model.Bodu;
            pagesDTO.HasSidebar = model.HasSidebar;

            storeRepository.Update(pagesDTO);
            //Сообщение пользователю
            TempData["SM"] = "You have edited the page!";

            //Переадресация обратно
            return RedirectToAction("EditPage");
        }
        //Admin/Pages/PageDetails/id
        //Получение деталей
        [HttpGet]
        public IActionResult PageDetails(int id)
        {
            //Моедль данных 
            PageVModel model;

            pagesDTO = storeRepository.GetPage<PagesDTO>(id);

            //Проверка на НАЛЛ страницу
            if(storeRepository == null)
            {
                return Content("The page does not exist!");
            }

            //Присваиваем данные  Из DB все поля
            model = new PageVModel(pagesDTO);

            return View(model);
        }
        //GEt: Admin/Pages/DeletePages/id
        //Удаление
        [HttpGet]
        public IActionResult DeletePage(int id)
        {
            //Вызываем метод и Репозитория
            storeRepository.Delete<PagesDTO>(id);

            TempData["SM"] = "You have delete a page!";

            return RedirectToAction("index");
        }

        //Admin/Pages/ReorderPages
        //создаём метод сортировки в базе данных который записывает изменения при перетаскивании
        [HttpPost]
        public void ReorderPages(int[] id)
        {
            //Начальный счётчик
            //home по умолчанию 0
            int count = 1; 
            //Сортировка для каждой таблици
            foreach(var pageId in id)
            {
                //получаем обьект
                var model = storeRepository.GetPage<PagesDTO>(pageId);
                model.Sorting = count;
                //СОхраняем обьект
                storeRepository.Update(model);
                //storeRepository.SortingCount(pageId, count);

                count++; 
            }

        }
        
        //Получение страници SideBar для редактирования
        [HttpGet]
        public IActionResult EditSideBar()
        {
            SidebarDTO dto = new();
            //полученре страници
            dto = storeRepository.GetPage<SidebarDTO>(1);

            return View(dto);
        }
    
        //Редактирование полученной страници
        [HttpPost]
        public IActionResult EditSideBar(SidebarDTO model)
        {
            SidebarDTO dto = new();          
            dto = storeRepository.GetPage<SidebarDTO>(model.Id); //get side bar            
            dto.Bodu = model.Bodu;
            storeRepository.Update(dto);

            TempData["SM"] = "You have edited the sidebar!";

            return RedirectToAction("EditSideBar");
        }
    }
}
