﻿using Microsoft.AspNetCore.Mvc;
using MVC.Services;
using MvcModels.Data;

namespace MVC.Controllers
{
    public class ShopController : Controller
    {
        private readonly IStoreDbRepository storeDbRepository;
        private readonly IWebHostEnvironment webHostEnvironment;

        public ShopController(IStoreDbRepository storeDbRepository, IWebHostEnvironment webHostEnvironment)
        {
            this.storeDbRepository = storeDbRepository;
            this.webHostEnvironment = webHostEnvironment;
        }
        public IActionResult Index()
        {
            return RedirectToAction("Index", "Pages");
        }

        public IActionResult Category(string slug)
        {
            //Get : получаем категории
            List<ProductDTO> produts;

            int id;

            //получаем категорию  по слагу и присваиваем её id и имя
            var categoryDTO = storeDbRepository.GetTableForRequest<CategoryDTO>().FirstOrDefault(x => x.Slug == slug);
            id = categoryDTO.Id;
            var categoryName = categoryDTO.Name;

            //Получаем товары по категориии
            produts = storeDbRepository.GetTableForRequest<ProductDTO>().Where(x => x.CategoryId == id).ToList();

            //Имя категориии для ViewBag
            TempData["CatName"] = categoryName;

            return View(produts);
        }

        //Атрибут  переименования  метода
        [ActionName("produts-details")]
        public IActionResult ProdutsDetails(string name)
        {
            //Get: Shop/produts-details/name
            //Метод для получение  и вывода карточки товара

            //получаем товар по Slug
            ProductDTO dto = storeDbRepository.GetTableForRequest<ProductDTO>().FirstOrDefault(x => x.Slug == name);

            //Проверка 
            if (dto == null)
                RedirectToAction("Index", "Pages");

            // id товара
            int id = dto.Id;

            //Получаем изображение из галереи
            //Создаём путь
            var imagesDirectory = Path.Combine(webHostEnvironment.WebRootPath, "Imagess\\Uploads\\Products\\" + id + "\\Gallery\\Thumbs");
            //Получаем все  фото
            dto.GalleryImages = Directory.EnumerateFiles(imagesDirectory).Select(fn => Path.GetFileName(fn));

            return View("ProdutsDetails", dto);
        }
    }
}
