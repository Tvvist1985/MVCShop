﻿using Microsoft.AspNetCore.Mvc;

namespace MVC.Controllers
{
    public class AjaxController : Controller
    {
        public IActionResult Index()
        {
            
            return View();
        }

        public IActionResult AjaxPartial(string name)
        {
            //Метод возвращает частичное  с данными  через скрипт

            return PartialView("_AjaxPartial", name);
        }

        [HttpPost]
        public IActionResult AjaxPost(string? name)
        {
            //Метод возвращает форму и именем
            @TempData["Name"] = name;

            return PartialView("_AjaxPostPartial");
        }
    }
}
