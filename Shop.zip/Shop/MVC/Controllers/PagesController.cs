﻿using Microsoft.AspNetCore.Mvc;
using MVC.Services;
using MvcModels.Data;

namespace MVC.Controllers
{
    public class PagesController : Controller
    {
        private readonly IStoreDbRepository storeDbRepository;

        public PagesController(IStoreDbRepository storeDbRepository)
        {
            this.storeDbRepository = storeDbRepository;
        }

        [HttpGet]
        public IActionResult Index(string page = "")
        {            
            //Получаем краткий заголовок  (Slug) 
            if (page == "")            
                page = "home";
            
            //Проверяем , доступна ли страница
            //Ишем каконибуть элемент который соответствует нашему Slug  
            if (!storeDbRepository.GetTableForRequest<PagesDTO>().Any(x => x.Slug.Equals(page)))               
                return RedirectToAction("Index", new { page = "" });  //если не найдено переадресовываем  yна Index со значением пустая строка

            //Получам страницу из DB
            PagesDTO dto = storeDbRepository.GetTableForRequest<PagesDTO>().FirstOrDefault(x => x.Slug == page);

            //Устанавливаем заголовок Title
            ViewBag.PageTitle = dto.Title;
            //проверяем боковую 
            if(dto.HasSidebar == true) ViewBag.Sidebar = "Yes";
            else ViewBag.Sidebar = "No";

            return View(dto);
        }       

    }
}
