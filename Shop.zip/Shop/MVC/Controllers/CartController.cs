﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC.Services;
using MVC.Services.MailServce;
using MvcModels.Account;
using MvcModels.Cart;
using MvcModels.Data;
using MvcModels.Order;
using System.Text.Json;


namespace MVC.Controllers
{
    public class CartController : Controller
    {
        private readonly IStoreDbRepository storeDbRepository;
        private readonly MailService mail;

        public CartController(IStoreDbRepository storeDbRepository, MailService mail)
        {
            this.storeDbRepository = storeDbRepository;
            this.mail = mail;
        }
      
        //Get: получаем карзину
        public async Task< IActionResult> Index()
        {                                              
            //получаем данные из куки
            var listCartCookie = HttpContext.GetCookie<List<CartVM>>("cart1");

            //проверяем есьт ли добавленные товары в сессии
            if (listCartCookie == null)
            {
                TempData["MS"] = "Your cart is empty.";

                return View();
            }
                    
            decimal total = 0m;
            //Складываем  цену
            foreach (var item in listCartCookie)            
                total += item.Total;
            
            //Передаём на страницу общуу цену
            ViewBag.GrandTotal = total;

            return View("Index", listCartCookie);
        }

        //Метод добавления в карзину товара
        public IActionResult AddToCartPartial(int id)
        {
                     
            //Переменная на наличие товара в карзине
            CartVM? productInCart = null;

            //Обьявляем модель
            CartVM model = new CartVM();

            //Переменная списка товаров
            List<CartVM> valueCart = new List<CartVM>();

            //Получаем продукт по Id         
            ProductDTO product = storeDbRepository.GetPage<ProductDTO>(id);

            //Проверяем наличае сессии
            //var sassionCart = HttpContext.Session.Keys.Contains("cart");

            //Проверяем наличаее куки 
            var cookieCart = Request.Cookies.ContainsKey("cart1");

            //Проверка наличие товара в карзине и очиста сессии
            if (cookieCart)
            {
                //Получение данных сессии
                //valueCart = HttpContext.Session.Get<List<CartVM>>("cart");

                //Получаем данные куки
                valueCart = HttpContext.GetCookie<List<CartVM>>("cart1");

                //Проверяем есть ли товар в карзине
                productInCart = valueCart.FirstOrDefault(x => x.ProductId == id);

                //Очищаем сессию 
                HttpContext.Session.Clear();
            }

            //Если товара нет в карзине то добавляем новый товар
            if (productInCart == null)
            {
                valueCart.Add(new CartVM()
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    Quantity = 1,
                    Price = product.Price,
                    Image = product.ImageName
                });
            }
            //Если товар есть    то добавляем ещё 1 еденицу товара
            else            
                productInCart.Quantity++;
            

            //Добавляем обшее количество и общуу цену
            int qty = 0;
            decimal price = 0m;

            foreach (var item in valueCart)
            {
                qty += item.Quantity;
                price += item.Quantity * item.Price;
            }
            //присваивем данные модели
            model.Quantity = qty;
            model.Price = price;

            //Создаём  сессию корзины
            //HttpContext.Session.Set<List<CartVM>>("cart", valueCart);

            //Создаём куку карзины
            HttpContext.SetCookie("cart1", valueCart);
          
            return PartialView("~/Views/Shared/Components/Cart/_CartPartial.cshtml", model);
        }

        public IActionResult IncrementProduct(int productId)
        {
            //GeT: Возвращает Json инкремент  через Index
            //..............................................

            //Получаем данные из сессии
            //List<CartVM> cart = HttpContext.Session.Get<List<CartVM>>("cart");

            //Получаем данные куки
            List<CartVM> cart = HttpContext.GetCookie<List<CartVM>>("cart1");

            //Получаем модель из корзины
            CartVM model = cart.FirstOrDefault(x => x.ProductId == productId);           
            
            //Добавляем количество
            model.Quantity++;

            //Заменяем в куке количество товаров
            cart[cart.FindIndex(x => x.ProductId == productId)] = model;

            //Сохраняем данняе для JSON
            var result = new {qty = model.Quantity, price = model.Price};

            //Сохраням сессию 
            //HttpContext.Session.Set<List<CartVM>>("cart", cart);

            //сохраняем куку
            HttpContext.SetCookie("cart1", cart);

            return Json(result);
            
        } 

        public IActionResult DecrementProduct(int productId)
        {
            //GeT: Возвращает Json декремента  через Index
            //..............................................

            //Получаем данные из сессии
            //List<CartVM> cart = HttpContext.Session.Get<List<CartVM>>("cart");

            //Получаем данные куки
            List<CartVM> cart = HttpContext.GetCookie<List<CartVM>>("cart1");

            //Получаем модель из корзины
            CartVM model = cart.FirstOrDefault(x => x.ProductId == productId);

            //Отнимаем количество количество
            if(model.Quantity > 1)
            {
                model.Quantity--;
                //Заменяем в сессии модель с количеством товаров
                cart[cart.FindIndex(x => x.ProductId == productId)] = model;
            }
            else
            {
                model.Quantity = 0;
                cart.Remove(model);
            }
          
            //Сохраняем данняе для JSON
            var result = new { qty = model.Quantity, price = model.Price };

            //Сохраням сессию 
            //HttpContext.Session.Set<List<CartVM>>("cart", cart);

            //сохраняем куку
            HttpContext.SetCookie("cart1", cart);

            return Json(result);
        }
        //GeT: Возвращает Json декремента  через Index
        public void RemoveProduct(int productId)
        {                       
            //Получаем данные из сессии
            //List<CartVM> cart = HttpContext.Session.Get<List<CartVM>>("cart");

            //Получаем данные куки
            List<CartVM> cart = HttpContext.GetCookie<List<CartVM>>("cart1");

            //Получаем модель из корзины
            CartVM model = cart.FirstOrDefault(x => x.ProductId == productId);

            //Удаляем товар
            cart.Remove(model);
           
            //Сохраням сессию 
            //HttpContext.Session.Set<List<CartVM>>("cart", cart);

            //сохраняем куку
            HttpContext.SetCookie("cart1", cart);
        }

        //Возвращает частичное  и данными из Ajax корзины товаров     .. вызываеться из скрипта  на Cart/ Index
        public IActionResult PaypalPartial()
        {                                         
            //Получаем данные куки
            List<CartVM> cart = HttpContext.GetCookie<List<CartVM>>("cart1");

            return PartialView("PaypalPartial", cart);
        }

        [HttpPost]       
        //Сохраняет заказ в базу  + отправка Сообщение на почту + после отправляет форму на PayPal  всё через JS
        public async void PlaceOrder()
        {                            
            //Получаем данные куки корзины
            List<CartVM> cart = HttpContext.GetCookie<List<CartVM>>("cart1");
                     
            //Получаем id пользователя 
            var user = storeDbRepository.DirectRequestToDatabase(p => p.Users.FirstOrDefault(p => p.UserName == User.Identity.Name));

            foreach (var product in cart)  //Add data to DB
            {
                OrderDTO dto = new OrderDTO()
                {
                    CreatedAt = DateTime.Now,
                    OrderDetails = new OrderDetailsDTO()
                    {
                        FirstName = user.FirstName,
                        LastName = user.LastName,
                        EmailAdress = user.EmailAdress,
                        ProductName = product.ProductName,
                        Price = product.Price,
                        Quantity = product.Quantity
                    }
                };

                storeDbRepository.Add(dto);     //Saving  to db
            }

            //Отправляем письмо  на Почту
            //await mail.SendEmailAsync("fl-13@mail.ru", "Тема письма", "Тест письма: тест! ");

            //Удаляем куку
            Response.Cookies.Delete("cart1");            
        }

        [HttpGet]
        //Method: Show all orders of the current user
        public IActionResult GetOrder()
        {
            var email = storeDbRepository.DirectRequestToDatabase(p => p.Users.AsNoTracking().FirstOrDefault(p => p.UserName == User.Identity.Name).EmailAdress); //Get user email
            var listOrders = storeDbRepository.DirectRequestToDatabase(p => p.Orders  //Get all orders current user
            .Where(p => p.OrderDetails.EmailAdress == email)
            .Select(p => new 
            {
                p.CreatedAt,
                p.OrderDetails.FirstName,
                p.OrderDetails.LastName,
                p.OrderDetails.EmailAdress,
                p.OrderDetails.ProductName,
                p.OrderDetails.OrderId,
                p.OrderDetails.Price,   
                p.OrderDetails.Quantity
            }).ToList());

            var json = JsonSerializer.Serialize(listOrders); // Serialized to json           
            List<OrdersForUserVM> ordersForUser = JsonSerializer.Deserialize<List<OrdersForUserVM>>(json); //Dererialize to OrderVM
                     
            return View(ordersForUser);
        }
    }   
}
