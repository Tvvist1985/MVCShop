﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using MVC.Services;
using MvcModels.Account;
using MvcModels.Data;
using MvcModels.Order;
using System.Security.Claims;

namespace MVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly IStoreDbRepository storeDbRepository;

        public AccountController(IStoreDbRepository storeDbRepository)
        {
            this.storeDbRepository = storeDbRepository;
        }
        public IActionResult Index() => RedirectToAction("Login");
                
        [HttpGet]
        //Method: Get page for create account.
        public IActionResult CreateAccount() => View("CreateAccount");
       
        [HttpPost]
        public IActionResult CreateAccount(UserDTO model)
        {           
            //проверка на валидность
            if(!ModelState.IsValid)            
                return RedirectToAction("CreateAccount");
            
            //проверяем на соответствие пароля
            if(!model.Password.Equals(model.ConfirmPassword))
            {
                ModelState.AddModelError("", "Password do not match!");
                return View("CreateAccount", model); 
            }

            //Проверяем имя  на уникальность
            if(storeDbRepository.GetTableForRequest<UserDTO>().Any(x => x.UserName.Equals(model.UserName)))
            {
                ModelState.AddModelError("", $"Username {model.UserName} is taken.");
                return View("CreateAccount", model);
            }

            //Добавляем в базу пользователя
            storeDbRepository.Add(model);
            //Присваиваем роль пользователю
            UserRoleDTO userRole = new UserRoleDTO()
            {
                UserId = model.Id,
                RoleId = 2
            };
            //Добавляем в базу пользователя
            storeDbRepository.Add(userRole);

            //Сообщений
            TempData["SM"] = "You are now registered and can login!";
            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult Login()
        {
            //GET: Проверка на Аунтефикацию
            //.......................................

            //Подтвердить что пользователь неавторизован
            var userName = User.Identity.Name;

            if (!string.IsNullOrEmpty(userName))
                return RedirectToAction("UseProfile");

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginUserVM model)
        {
            //GET: мотод Аутентификации и записи в куке в случае существующего пользователя
            //.......................................

            //Проверям модель на валидность
            if (!ModelState.IsValid)            
                return View(model);
            

            bool isValid = false;

            //прорверяем по имени и паролю есть ли пользователь в базе
            if (storeDbRepository.GetTableForRequest<UserDTO>().Any(x => x.UserName.Equals(model.UserName) && x.Password.Equals(model.Password)))            
                isValid = true; 
            
            if (!isValid)
            {
                ModelState.AddModelError("", "Invalid username or password!");
                return View(model);
            }          
            else
            {
                //Метод сохранения пользователя в куки  (он ниже)
                await Authenticate(model.UserName);              

                return Redirect("~/Pages/Index");
            }
        }

        //Добавляем пользователя в COOKIE
        private async Task Authenticate(string userName)
        {                               
            //Устанавливаем данные  позьзователя для аунтефикации (Ник и  роли)
            //сюда не нужно передавать пароль   чтобы кука не хранила его  +  чем меньше в куках данных  тем она легче
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, userName )
            };
            //получаем обьект
            UserDTO dto = storeDbRepository.GetTableForRequest<UserDTO>().FirstOrDefault(x => x.UserName == userName);
            //Ищем все роли обьекта
            string[] roles = storeDbRepository.GetTableForRequest<UserRoleDTO>().Where(x => x.UserId == dto.Id).Select(x => x.Role.Name).ToArray();
           
            foreach (var role in roles)        //add role to clame list      
                claims.Add(new Claim(ClaimTypes.Role, role));
            
            // создаем объект с данными  и ключём для  Identity
            ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, "Cookies");

            //установка  время куки авторизации
            var rwe = new AuthenticationProperties()
            {
                IsPersistent = true,
                ExpiresUtc = DateTimeOffset.UtcNow.AddDays(7)
            };
         
            //Создаём  и записываем данные в COOKIE для аунтефикации
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), rwe);
        }
        
        public IActionResult Logout()
        {
            //Удаление куки
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme).Wait() ;
            Response.Cookies?.Delete("cart1"); //delete cookie cart
            return RedirectToAction("Login", "Account");
        }

        [HttpGet]
        public IActionResult UseProfile()
        {
            //Возвращает страницу для редактирования Профиля
            //.............................................

            //получаем  имя пользователя из куки
            var userName = User.Identity.Name;

            //Ищем в базе пользователя
            UserDTO dto = storeDbRepository.GetTableForRequest<UserDTO>().FirstOrDefault(x => x.UserName == userName);

            return View("UserProfile", dto);
        }

        [HttpPost]
        public async Task<IActionResult> UseProfile(UserDTO model)
        {
            //Редактирует Профиль
            //.............................................

            //Переменная для исправление бага
            bool userNamberIsChanged = false;

            //Валидация модели
            if(!ModelState.IsValid)
            {
                return View("UserProfile", model);
            }

            //проверяем пароль 
            if(!string.IsNullOrEmpty(model.Password))
            {
                if(!model.Password.Equals(model.ConfirmPassword))
                {
                    ModelState.AddModelError("", "Password do not match.");
                    return View("UserProfile", model);
                }
            }

            //Получаем новое имя модели
            string userName = User.Identity.Name;

            //проверяем измениелось ли имя из в моделеи по сравнению с куки (тут тоже обходим баг)
            if(userName != model.UserName)
            {
                userName = model.UserName;
                userNamberIsChanged = true;
            }

            //проверяем имя на уникальность
            if(storeDbRepository.GetTableForRequest<UserDTO>().Where(x => x.Id != model.Id).Any(x => x.UserName == userName))
            {
                ModelState.AddModelError("", $"Username {userName} alredy exists.");
                model.UserName = "";
                return View("UserProfile", model);
            }

            storeDbRepository.Update(model);
           
            TempData["SM"] = "You have edited your profile!";

            if (!userNamberIsChanged)
                return View("UserProfile", model);
            else
                return RedirectToAction("Logout");
        }

        //Method: Delete Profile
        [HttpGet]
        public IActionResult DeleteProf(int id)
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme).Wait(); //remove cookie indentity
            storeDbRepository.Delete<UserDTO>(id); //delete user from db                                                  
            Response.Cookies?.Delete("cart1"); //delete cookie cart

            return Redirect("~/Pages/Index");
        }
    }
}
