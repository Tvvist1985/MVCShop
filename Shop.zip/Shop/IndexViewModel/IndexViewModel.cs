﻿using MvcModels.Data;

namespace MvcIndexViewModel
{
    //Инкапсюляция для сортировки  фильтра и пагинации    По общий
    public class IndexViewModel
    {
        public IEnumerable<ProductDTO> Products { get; }
        public PageViewModel PageViewModel { get; }
        public FilterViewModel FilterViewModel { get; }
        public SortViewModel SortViewModel { get; }
        public IndexViewModel(IEnumerable<ProductDTO> products, PageViewModel pageViewModel,
            FilterViewModel filterViewModel, SortViewModel sortViewModel)
        {
            Products = products;
            PageViewModel = pageViewModel;
            FilterViewModel = filterViewModel;
            SortViewModel = sortViewModel;
        }
    }
}
