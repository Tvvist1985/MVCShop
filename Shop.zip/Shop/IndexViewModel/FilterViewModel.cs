﻿using Microsoft.AspNetCore.Mvc.Rendering;
using MvcModels.Data;

namespace MvcIndexViewModel
{
    public class FilterViewModel
    {
        public SelectList Categories { get; } // список компаний
        public int SelectedCategory { get; } // выбранная компания
        public string SelectedName { get; } // введенное имя

        public FilterViewModel(List<CategoryDTO> categories, int category, string name)
        {
            // устанавливаем начальный элемент, который позволит выбрать всех
            categories.Insert(0, new CategoryDTO { Name = "Все", Id = 0 });
            Categories = new SelectList(categories, "Id", "Name", category);
            SelectedCategory = category;
            SelectedName = name;
        }
        
    }

}