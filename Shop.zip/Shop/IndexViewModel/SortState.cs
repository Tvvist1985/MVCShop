﻿namespace MvcIndexViewModel
{
    public enum SortState
    {
        NameAsc,    // по имени по возрастанию
        NameDesc,   // по имени по убыванию
        CategoryAsc, // по категории по возрастанию
        CategoryDesc // по категории по убыванию
    }
}
